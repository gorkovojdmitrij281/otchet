AgriSubsidy - Django skeleton for Ministry of Agriculture subsidy management system.

Quickstart (local, without Docker):
1. Create and activate virtualenv:
   python -m venv venv
   source venv/bin/activate   (on Windows: venv\Scripts\activate)
2. Install requirements:
   pip install -r requirements.txt
3. Create .env file (see .env) or copy provided .env and set SECRET_KEY.
4. Apply migrations:
   python manage.py migrate
5. Create superuser:
   python manage.py createsuperuser
6. Run development server:
   python manage.py runserver

With Docker:
1. docker-compose up --build
2. Service will be available on http://localhost:8000

Notes:
- This repository is a skeleton: adjust settings, SECRET_KEY, and production configuration before deployment.
- Models, serializers and API endpoints are basic and intended as a starting point for the coursework.
