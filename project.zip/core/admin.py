from django.contrib import admin
from .models import Farmer, AgriculturalLand, Employee, SubsidyApplication, ApplicationItem, Payment, Report, Indicator

admin.site.register(Farmer)
admin.site.register(AgriculturalLand)
admin.site.register(Employee)
admin.site.register(SubsidyApplication)
admin.site.register(ApplicationItem)
admin.site.register(Payment)
admin.site.register(Report)
admin.site.register(Indicator)
