from django.db import models
from django.contrib.auth.models import User

class Farmer(models.Model):
    full_name = models.CharField(max_length=200)
    organization = models.CharField(max_length=200, blank=True)
    contact_info = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return self.full_name

class AgriculturalLand(models.Model):
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE, related_name='lands')
    area = models.DecimalField(max_digits=12, decimal_places=2)
    location = models.CharField(max_length=255, blank=True)
    land_type = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return f"Land {self.id} ({self.area})"

class Employee(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    position = models.CharField(max_length=100, blank=True)
    department = models.CharField(max_length=100, blank=True)

    def __str__(self):
        return self.user.get_full_name() or self.user.username

class SubsidyApplication(models.Model):
    STATUS_CHOICES = [
        ('draft','Draft'),
        ('submitted','Submitted'),
        ('under_review','Under review'),
        ('awaiting_docs','Awaiting documents'),
        ('approved','Approved'),
        ('rejected','Rejected'),
        ('payment_scheduled','Payment scheduled'),
        ('paid','Paid'),
        ('closed','Closed'),
    ]
    farmer = models.ForeignKey(Farmer, on_delete=models.CASCADE, related_name='applications')
    land = models.ForeignKey(AgriculturalLand, on_delete=models.SET_NULL, null=True, blank=True)
    status = models.CharField(max_length=30, choices=STATUS_CHOICES, default='draft')
    application_date = models.DateField(auto_now_add=True)
    requested_amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    approved_amount = models.DecimalField(max_digits=12, decimal_places=2, null=True, blank=True)
    handled_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True, blank=True)

    def __str__(self):
        return f"Application {self.id} - {self.farmer}"

class ApplicationItem(models.Model):
    application = models.ForeignKey(SubsidyApplication, on_delete=models.CASCADE, related_name='items')
    description = models.CharField(max_length=255)
    quantity = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    unit = models.CharField(max_length=50, blank=True)
    amount = models.DecimalField(max_digits=12, decimal_places=2, default=0)

    def __str__(self):
        return f"Item {self.id} for App {self.application.id}"

class Payment(models.Model):
    application = models.OneToOneField(SubsidyApplication, on_delete=models.CASCADE, related_name='payment')
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    payment_date = models.DateField(null=True, blank=True)
    bank_reference = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return f"Payment {self.id} - {self.amount}"

class Report(models.Model):
    period_start = models.DateField()
    period_end = models.DateField()
    created_by = models.ForeignKey(Employee, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Report {self.id}: {self.period_start} - {self.period_end}"

class Indicator(models.Model):
    report = models.ForeignKey(Report, on_delete=models.CASCADE, related_name='indicators')
    name = models.CharField(max_length=200)
    value = models.DecimalField(max_digits=14, decimal_places=4)
    unit = models.CharField(max_length=50, blank=True)

    def __str__(self):
        return f"{self.name}: {self.value}"
