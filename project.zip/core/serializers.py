from rest_framework import serializers
from .models import Farmer, AgriculturalLand, SubsidyApplication, ApplicationItem, Payment, Report, Indicator, Employee

class FarmerSerializer(serializers.ModelSerializer):
    class Meta:
        model = Farmer
        fields = '__all__'

class AgriculturalLandSerializer(serializers.ModelSerializer):
    class Meta:
        model = AgriculturalLand
        fields = '__all__'

class ApplicationItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = ApplicationItem
        fields = '__all__'

class SubsidyApplicationSerializer(serializers.ModelSerializer):
    items = ApplicationItemSerializer(many=True, read_only=True)
    class Meta:
        model = SubsidyApplication
        fields = '__all__'

class PaymentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = '__all__'

class ReportSerializer(serializers.ModelSerializer):
    class Meta:
        model = Report
        fields = '__all__'

class IndicatorSerializer(serializers.ModelSerializer):
    class Meta:
        model = Indicator
        fields = '__all__'
