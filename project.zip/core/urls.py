from rest_framework import routers
from django.urls import path, include
from .views import (
    FarmerViewSet, AgriculturalLandViewSet, SubsidyApplicationViewSet,
    ApplicationItemViewSet, PaymentViewSet, ReportViewSet, IndicatorViewSet
)

router = routers.DefaultRouter()
router.register(r'farmers', FarmerViewSet)
router.register(r'lands', AgriculturalLandViewSet)
router.register(r'applications', SubsidyApplicationViewSet)
router.register(r'items', ApplicationItemViewSet)
router.register(r'payments', PaymentViewSet)
router.register(r'reports', ReportViewSet)
router.register(r'indicators', IndicatorViewSet)

urlpatterns = [
    path('', include(router.urls)),
]
