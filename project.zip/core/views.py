from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from .models import Farmer, AgriculturalLand, SubsidyApplication, ApplicationItem, Payment, Report, Indicator
from .serializers import (
    FarmerSerializer, AgriculturalLandSerializer, SubsidyApplicationSerializer,
    ApplicationItemSerializer, PaymentSerializer, ReportSerializer, IndicatorSerializer
)

class FarmerViewSet(viewsets.ModelViewSet):
    queryset = Farmer.objects.all()
    serializer_class = FarmerSerializer

class AgriculturalLandViewSet(viewsets.ModelViewSet):
    queryset = AgriculturalLand.objects.all()
    serializer_class = AgriculturalLandSerializer

class SubsidyApplicationViewSet(viewsets.ModelViewSet):
    queryset = SubsidyApplication.objects.all().order_by('-application_date')
    serializer_class = SubsidyApplicationSerializer

    @action(detail=True, methods=['post'])
    def set_status(self, request, pk=None):
        app = self.get_object()
        status_value = request.data.get('status')
        if status_value and status_value in dict(SubsidyApplication.STATUS_CHOICES):
            app.status = status_value
            app.save()
            return Response({'status':'ok','new_status':app.status})
        return Response({'status':'error','detail':'invalid status'}, status=400)

class ApplicationItemViewSet(viewsets.ModelViewSet):
    queryset = ApplicationItem.objects.all()
    serializer_class = ApplicationItemSerializer

class PaymentViewSet(viewsets.ModelViewSet):
    queryset = Payment.objects.all()
    serializer_class = PaymentSerializer

class ReportViewSet(viewsets.ModelViewSet):
    queryset = Report.objects.all()
    serializer_class = ReportSerializer

class IndicatorViewSet(viewsets.ModelViewSet):
    queryset = Indicator.objects.all()
    serializer_class = IndicatorSerializer
