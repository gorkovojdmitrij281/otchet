#!/bin/sh
python manage.py migrate
python manage.py loaddata core/fixtures/initial_data.json
